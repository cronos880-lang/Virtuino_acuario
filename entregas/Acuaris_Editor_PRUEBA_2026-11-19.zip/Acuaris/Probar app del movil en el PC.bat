@echo off
rem Abre la app (la que va al movil) en el PC, con el simulador del acuario.
start "" "%~dp0Acuaris.exe" -- --app
